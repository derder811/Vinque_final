-- Production Database Initialization Script
-- This script sets up the database with proper production settings

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS vinque_production CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Use the production database
USE vinque_production;

-- Create production user with limited privileges
CREATE USER IF NOT EXISTS 'vinque_user'@'%' IDENTIFIED BY 'CHANGE_THIS_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE ON vinque_production.* TO 'vinque_user'@'%';
FLUSH PRIVILEGES;

-- Set production-specific MySQL settings
SET GLOBAL innodb_buffer_pool_size = 134217728; -- 128MB
SET GLOBAL max_connections = 200;
SET GLOBAL query_cache_size = 16777216; -- 16MB
SET GLOBAL slow_query_log = 1;
SET GLOBAL long_query_time = 2;

-- Create accounts table if it doesn't exist
CREATE TABLE IF NOT EXISTS accounts (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255),
    role ENUM('Customer', 'Seller', 'Admin') DEFAULT 'Customer',
    First_name VARCHAR(100),
    Last_name VARCHAR(100),
    phone_num VARCHAR(20),
    address TEXT,
    Business_Permit VARCHAR(255),
    profile_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB;

-- Create customer_tb table if it doesn't exist
CREATE TABLE IF NOT EXISTS customer_tb (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    First_name VARCHAR(100),
    Last_name VARCHAR(100),
    email VARCHAR(255),
    phone_num VARCHAR(20),
    address TEXT,
    profile_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES accounts(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- Create seller_tb table if it doesn't exist
CREATE TABLE IF NOT EXISTS seller_tb (
    seller_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    business_name VARCHAR(255),
    First_name VARCHAR(100),
    Last_name VARCHAR(100),
    email VARCHAR(255),
    phone_num VARCHAR(20),
    address TEXT,
    paypal_number VARCHAR(255),
    approval_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    business_permit_file VARCHAR(255),
    profile_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES accounts(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_email (email),
    INDEX idx_approval_status (approval_status)
) ENGINE=InnoDB;

-- Create products table if it doesn't exist
CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT,
    product_name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(100),
    stock_quantity INT DEFAULT 0,
    image1 VARCHAR(255),
    image2 VARCHAR(255),
    image3 VARCHAR(255),
    is_archived BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES seller_tb(seller_id) ON DELETE CASCADE,
    INDEX idx_seller_id (seller_id),
    INDEX idx_category (category),
    INDEX idx_archived (is_archived),
    INDEX idx_price (price)
) ENGINE=InnoDB;

-- Create orders table if it doesn't exist
CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    seller_id INT,
    product_id INT,
    quantity INT NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'confirmed', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    shipping_address TEXT,
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customer_tb(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES seller_tb(seller_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    INDEX idx_customer_id (customer_id),
    INDEX idx_seller_id (seller_id),
    INDEX idx_product_id (product_id),
    INDEX idx_status (status),
    INDEX idx_payment_status (payment_status),
    INDEX idx_order_date (order_date)
) ENGINE=InnoDB;

-- Create cart table if it doesn't exist
CREATE TABLE IF NOT EXISTS cart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customer_tb(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    UNIQUE KEY unique_customer_product (customer_id, product_id),
    INDEX idx_customer_id (customer_id)
) ENGINE=InnoDB;

-- Create sessions table for session management
CREATE TABLE IF NOT EXISTS sessions (
    session_id VARCHAR(128) PRIMARY KEY,
    user_id INT,
    expires_at TIMESTAMP NOT NULL,
    data TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES accounts(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB;

-- Create audit log table for security
CREATE TABLE IF NOT EXISTS audit_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES accounts(user_id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Create OTP table for email verification
CREATE TABLE IF NOT EXISTS otp_codes (
    otp_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB;

-- Insert default admin user (update password after deployment)
INSERT IGNORE INTO accounts (email, password, role, First_name, Last_name) 
VALUES ('admin@vinque.store', '$2b$10$defaulthashedpassword', 'Admin', 'System', 'Administrator');

-- Create views for common queries
CREATE OR REPLACE VIEW active_products AS
SELECT p.*, s.business_name, s.First_name as seller_first_name, s.Last_name as seller_last_name
FROM products p
JOIN seller_tb s ON p.seller_id = s.seller_id
WHERE p.is_archived = FALSE AND s.approval_status = 'approved';

CREATE OR REPLACE VIEW order_summary AS
SELECT o.*, 
       c.First_name as customer_first_name, c.Last_name as customer_last_name,
       s.business_name, s.First_name as seller_first_name, s.Last_name as seller_last_name,
       p.product_name, p.price as unit_price
FROM orders o
JOIN customer_tb c ON o.customer_id = c.customer_id
JOIN seller_tb s ON o.seller_id = s.seller_id
JOIN products p ON o.product_id = p.product_id;

-- Create stored procedures for common operations
DELIMITER //

CREATE PROCEDURE IF NOT EXISTS GetUserProfile(IN p_user_id INT)
BEGIN
    SELECT a.*, 
           CASE 
               WHEN a.role = 'Customer' THEN c.customer_id
               WHEN a.role = 'Seller' THEN s.seller_id
               ELSE NULL
           END as profile_id
    FROM accounts a
    LEFT JOIN customer_tb c ON a.user_id = c.user_id
    LEFT JOIN seller_tb s ON a.user_id = s.user_id
    WHERE a.user_id = p_user_id;
END //

CREATE PROCEDURE IF NOT EXISTS CleanupExpiredSessions()
BEGIN
    DELETE FROM sessions WHERE expires_at < NOW();
    DELETE FROM otp_codes WHERE expires_at < NOW() OR used = TRUE;
END //

DELIMITER ;

-- Create event scheduler for cleanup (if not exists)
SET GLOBAL event_scheduler = ON;

CREATE EVENT IF NOT EXISTS cleanup_expired_data
ON SCHEDULE EVERY 1 HOUR
DO
  CALL CleanupExpiredSessions();

-- Optimize tables
OPTIMIZE TABLE accounts, customer_tb, seller_tb, products, orders, cart;

-- Show table status
SELECT 'Database initialization completed successfully' as status;
SHOW TABLES;

-- Display important information
SELECT 
    'IMPORTANT: Change default admin password after deployment!' as warning,
    'Default admin email: admin@vinque.store' as admin_email,
    'Update database user password in production!' as security_note;